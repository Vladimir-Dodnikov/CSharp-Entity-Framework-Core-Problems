﻿namespace FastFood.Core.ViewModels.Positions
{
    public class CreatePositionInputModel
    {
        public string PositionName { get; set; }
    }
}

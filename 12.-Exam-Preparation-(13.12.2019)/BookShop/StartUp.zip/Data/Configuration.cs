﻿namespace BookShop.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=.;Database=BookShop2;Trusted_Connection=True";
    }
}
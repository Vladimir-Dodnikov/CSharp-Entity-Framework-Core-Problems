﻿namespace P01_StudentSystem.Data
{
    internal static class Configuration
    {
        internal static string stringConnection = @"Server=DESKTOP-MQ67QHE;Database=StudentSystem;Integrated Security = true";
    }
}

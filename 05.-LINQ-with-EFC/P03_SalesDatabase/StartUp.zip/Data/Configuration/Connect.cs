﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P03_SalesDatabase.Data.Configuration
{
    public static class Connect
    {
        public static string stringConnection = @"Server=DESKTOP-MQ67QHE;Database=SalesDatabase;Integrated Security = true";
    }
}

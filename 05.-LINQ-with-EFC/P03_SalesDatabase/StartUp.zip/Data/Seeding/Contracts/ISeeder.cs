﻿namespace P03_SalesDatabase.Data.Seeding.Contracts
{
    public interface ISeeder
    {
        void Seed();
    }
}

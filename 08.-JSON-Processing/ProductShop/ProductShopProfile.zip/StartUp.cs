﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Newtonsoft.Json;
using ProductShop.Data;
using ProductShop.Models;

namespace ProductShop
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            ProductShopContext db = new ProductShopContext();
            ResetDatabase(db);


        }
        //Problem 01 - create/delete - ensure database.
        private static void ResetDatabase(ProductShopContext db)
        {
            db.Database.EnsureDeleted();
            Console.WriteLine("Database was successfully deleted.");

            db.Database.EnsureCreated();
            Console.WriteLine("Database was successfully created.");

            string inputJson = File.ReadAllText(@"D:\CSharp-Entity-Framework-Core-Problems\08.-JSON-Processing\ProductShop\Datasets\users.json");

            string result = ImportUsers(db, inputJson);
            Console.WriteLine(result);
        }
        //Problem 02
        public static string ImportUsers(ProductShopContext context, string inputJson)
        {
            //2 options - with DTO (AutoMapper)
            User[] users = JsonConvert.DeserializeObject<User[]>(inputJson);

            context.Users.AddRange(users);
            context.SaveChanges();

            return $"Successfully imported {users.Length}";
        }
    }
}